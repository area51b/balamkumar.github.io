var originalResponse = JSON.parse(context.proxyResponse.content);

var places = originalResponse.places;

var place = [];

if (places.place)
{
  for (var index = 0; index < places.place.length; index++){
    place[index] = {
      woeid: places.place[index].woeid,
      placeType: places.place[index].placeTypeName,
      name: places.place[index].name,
      country: places.place[index].country,
      timezone: places.place[index].timezone
    }
  }
}

var minimizeResponse = {
  places: place
};

context.proxyResponse.content = JSON.stringify(minimizeResponse);