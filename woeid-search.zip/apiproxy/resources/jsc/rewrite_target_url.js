var host = context.getVariable("target.url");
var place = context.getVariable("vars.place");

var view = "long";
var format= "json";
var appid = "dj0yJmk9RlNwTUdndXY3ZVd2JmQ9WVdrOVdrbHpNbUZpTkc4bWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD01NA--";

var target = host + "/v1/places.q('" + place + "')" 
  + "?view=" + view 
  + "&format=" + format
  + "&appid=" + appid;

context.setVariable("target.url", target);
context.setVariable("target.copy.pathsuffix", false);
context.setVariable("target.copy.queryparams", false);