var originalResponse = JSON.parse(context.proxyResponse.content);

var woeid = context.getVariable("vars.woeid");

var channel = originalResponse.rss.channel;
var forecast = [];

for (var index = 0; index < channel.item.forecast.length; index++){
  forecast[index] = {
    day: channel.item.forecast[index].day,
    date: channel.item.forecast[index].date,
    low: channel.item.forecast[index].low,
    high: channel.item.forecast[index].high,
    text: channel.item.forecast[index].text,
    code: channel.item.forecast[index].code,
  };
}
var description = channel.item.description;
var match =  description.match(/<img src="(.*)"\/>/i);
var url = match[1];

var minimizedResponse = { 
  forecast: {
    woeid: woeid,
    units: {
      temperature: channel.units.temperature,
      distance: channel.units.distance,
      pressure: channel.units.pressure,
      speed: channel.units.speed,
    },
    wind: {
      chill: channel.wind.chill,
      direction: channel.wind.direction,
      speed: channel.wind.speed
    },
    atmosphere: {
      humidity: channel.atmosphere.humidity,
      visibility: channel.atmosphere.visibility,
      pressure: channel.atmosphere.pressure,
      rising: channel.atmosphere.rising
    },
    astronomy: {
      sunrise: channel.astronomy.sunrise,
      sunset: channel.astronomy.sunset
    },
    condition: {
      text: channel.item.condition.text,
      code: channel.item.condition.code,
      image: url,
      temp: channel.item.condition.temp,
      date: channel.item.condition.date
    },
    location: {
      city: channel.location.city,
      region: channel.location.region,
      country: channel.location.country 
    },
    forecast: forecast
  }
};

context.proxyResponse.content = JSON.stringify(minimizedResponse);