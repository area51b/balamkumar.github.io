var host = context.getVariable("target.url");
var woeid = context.getVariable("vars.woeid");
var unit = context.getVariable("vars.unit");

var target = host + "/forecastrss" 
  + "?w=" + woeid 
  + "&u=" + unit;

context.setVariable("target.url", target);
context.setVariable("target.copy.pathsuffix", false);
context.setVariable("target.copy.queryparams", false);